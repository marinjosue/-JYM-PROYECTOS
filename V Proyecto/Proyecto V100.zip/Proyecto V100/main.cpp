/*************************
                UFA - ESPE
 * Module:  main.cpp
 * Author:  Chiliquinga Yeshua, Marin Alquinga,Salcedo Micaela
 * Modified: domingo, 17 de diciembre de 2023
 * Purpose: Crear una tabla de credito de amortizacion Francesa
 ***********************************************************************/
#include <iostream>
#include "Menu.cpp"

using namespace std;

int main()
{
    Menus menu;
    menu.Menu_Principal();
    return 0;
}
