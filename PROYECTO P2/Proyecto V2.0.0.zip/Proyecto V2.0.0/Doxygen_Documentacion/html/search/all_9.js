var searchData=
[
  ['validaciones_0',['validaciones',['../classvalidaciones.html',1,'']]],
  ['verificarcedula_1',['verificarCedula',['../class_persona.html#a9a55b279e78abc941547d9103f24d093',1,'Persona']]]
];
