var searchData=
[
  ['datostabla_0',['DatosTabla',['../struct_datos_tabla.html',1,'']]],
  ['datosusuario_1',['DatosUsuario',['../struct_datos_usuario.html',1,'']]]
];
