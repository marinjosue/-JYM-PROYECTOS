var searchData=
[
  ['menus_0',['Menus',['../class_menus.html',1,'']]],
  ['menuseleccion_1',['menuSeleccion',['../class_menus.html#ad8b7f27b1003506b93af2142a96789a5',1,'Menus']]],
  ['movimientos_2',['Movimientos',['../class_movimientos.html',1,'']]]
];
